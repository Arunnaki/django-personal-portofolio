from django.apps import AppConfig


class PortofolioConfig(AppConfig):
    name = 'portofolio'
